$(document).ready(function () {
    $("#Hidebutton").click(function(){
        $("p").hide()
    })
    $(document).ready(function(){
        $("#showbutton").click(function(){
            $("p").show()
        })
    })
})